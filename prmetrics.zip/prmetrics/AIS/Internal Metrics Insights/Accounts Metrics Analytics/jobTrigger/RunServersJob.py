import requests  
import os 
import json
import jenkins
import time

buildNumberArray = []
BuildResults = []
# creating server instance
def getServerInstance(apiUrl , userName , password):
    server_instance = jenkins.Jenkins(
        apiUrl,
        username = userName,
        password = password
    )
    return server_instance


def loadTheConfigFile() : 
    try:
        # Load current directory
        dir_path = os.path.dirname(os.path.realpath(__file__))
        configFile = open(dir_path + "/config.json", "r") 
        # Read configuration file
        configContent = configFile.read()
        # Convert string to Python dict 
        jsonConfigContent = json.loads(configContent)
        return jsonConfigContent

    except Exception as e:
        print(f"[Exception]: In using the configuration file: {e}")

def buildUrlToExecuteJob(jsonConfigContent) :
    jenkins_url = jsonConfigContent['jenkins_url']
    job_name = jsonConfigContent['job_name']
    job_token = jsonConfigContent['job_token']
    isTheJobParametrized = jsonConfigContent['isTheJobParametrized']

    if not isTheJobParametrized:
        url = "https://" + jenkins_url+'/job/'+job_name+'/build?token='+job_token
        my_data = None
    else:
        url = "https://" +  jenkins_url+'/job/'+job_name+'/buildWithParameters?token='+job_token
        my_data = jsonConfigContent['my_data']
    return [url , my_data]

def requestUrl(urlAndMyData , jsonConfigContent) :
    url = urlAndMyData[0]
    my_data = urlAndMyData[1]
    user = jsonConfigContent['user']
    user_token = jsonConfigContent['user_token']
    print("triggering URL " + url)
    result = requests.post(url, auth = (user, user_token), data=my_data)
    if int(result.status_code) != 201: 
        print(f"[Error]: Triggering remote job failed with status_code: {result.status_code}")
        print(f"job-url :{url} ")

def getTheNextBuildNumber(jsonConfigContent) :
    server = getServerInstance("https://" + jsonConfigContent['jenkins_url'] , jsonConfigContent['user'] , jsonConfigContent['user_token'])
    info = server.get_job_info(jsonConfigContent['job_name'])
    buildNumber = info['nextBuildNumber']
    buildNumberArray.append(buildNumber)
    print(buildNumber)

def waitTillFinish(jsonConfigContent , buildNumber) :
    server = getServerInstance("https://" + jsonConfigContent['jenkins_url'] , jsonConfigContent['user'] , jsonConfigContent['user_token'])
    while 1>0:
        try : 
            buildInformation = server.get_build_info(jsonConfigContent['job_name'], buildNumber)
            if(buildInformation['building'] == False) :
                break 
            if(buildInformation['building'] == True) :
                raise Exception("still building")
        except Exception as e:
            time.sleep(30)
    
    print(jsonConfigContent['job_name'] + " " + buildInformation['result'])
    BuildResults.append(buildInformation['result'])

        


def main():
    print("started")
    jsonConfig = loadTheConfigFile()
    for jsonConfigContent in jsonConfig:
        urlAndMyData = buildUrlToExecuteJob(jsonConfigContent)
        getTheNextBuildNumber(jsonConfigContent)
        requestUrl(urlAndMyData , jsonConfigContent)
    for jsonConfigContent in jsonConfig:
        buildNumber = buildNumberArray.pop(0)
        waitTillFinish(jsonConfigContent , buildNumber)
    for result in BuildResults :
        if(result != "SUCCESS") :
            raise Exception("Build Failure")



main() 
