import os
import json
import jenkins
import calendar
import time
import requests
import calendar
import time
from requests.auth import HTTPBasicAuth

#Global variables
individualMachineInfo = []
nodeType={}
machineTypeCount=[]

currentTimestamp = calendar.timegm(time.gmtime())
stringCurrentTimestamp=str(currentTimestamp)

currentTimestamp = calendar.timegm(time.gmtime())
stringCurrentTimestamp=str(currentTimestamp)

#Parse configuration file
def parseConfig():
        fullPath = os.path.realpath(__file__)
        cwd = os.path.dirname(fullPath)
        configFile = open(cwd+"/config.json", 'r')
        configContent = configFile.read()
        jsonConfigContent = json.loads(configContent)

        for individualServer in jsonConfigContent['servers']:
            url = individualServer["jenkinsUrl"]
            formattedURL= "https://"+url
            serverName = individualServer["name"]
            userid = individualServer["user"]
            apiToken = individualServer["userToken"]

            response = requests.get(formattedURL + '/computer/api/json',auth = HTTPBasicAuth(userid, apiToken))
            jsonObject = createJson()
            machineMetricsInfo(response, jsonObject, serverName, formattedURL)
            with open(serverName +"_machineMetrics_"+stringCurrentTimestamp+ ".json", "w") as f:
                json.dump(jsonObject, f, indent=2, default=str)

#Machine info of each server
def machineMetricsInfo(response,jsonObject, serverName, url):
    jsonResponse=response.json()
    machineArray=jsonResponse["computer"]
    totalNodes=totalMachines(machineArray)
    jsonObject['serverName'] = serverName
    jsonObject['serverUrl'] = url
    jsonObject['totalMachines'] = totalNodes
    individualMachineInfo.clear()
    machineTypeCount.clear()
    nodeType.clear()

    for node in machineArray:
        machineName=node['displayName']
        machineArchitecture=getMachineType(node)
        if(machineArchitecture!=None):
            freeDiskSpace=getDiskSpace(node)
            machineInfo={
                "nodeName":machineName,
                "nodeArchitecture":machineArchitecture,
                "freeDiskSpace":freeDiskSpace
            }
            addDescription(node,machineInfo,machineName)
            individualMachineInfo.append(machineInfo)
        

    updateJson(individualMachineInfo,jsonObject)   

def addDescription(node,machineInfo,machineName):
    if(machineName!="master"):
        description=node["description"]
        machineInfo["IP"]=description
    else:
        machineInfo["IP"]=" "
            

#Updating Json
def updateJson(machineInfoArray,jsonObject):
    for key in nodeType:
        data={
            "OS":key,
            "NumberOfMachines":nodeType[key]
        }
        machineTypeCount.append(data)
    jsonObject['machineTypeCount']=machineTypeCount
    jsonObject['machinesInfo']=machineInfoArray

#Finding free disk space in machine
def getDiskSpace(node):
    machineInfo=node['monitorData']
    diskSpaceMonitor=machineInfo['hudson.node_monitors.DiskSpaceMonitor']
    if(diskSpaceMonitor!=None):
        diskSpace=diskSpaceMonitor['size']
        diskSpaceinGb=getDiskSpaceInGb(diskSpace)
        return diskSpaceinGb

#Converting disk space in Gb
def getDiskSpaceInGb(diskSpace):
    dividend=1024*1024*1024
    diskSpaceGb=diskSpace/dividend
    diskSpaceTrim="{:.2f}".format(diskSpaceGb)
    diskSpaceString=str(diskSpaceTrim)+' '+'GB'
    return diskSpaceString

#Finding architecture of machine
def getMachineType(node):
    machineInfo=node['monitorData']
    machineType=machineInfo['hudson.node_monitors.ArchitectureMonitor']
    if(machineType!=None):
     before, sep, after = machineType.partition('(')
     machineType=before
    if machineType in nodeType:
      nodeType[machineType]+=1
    else:
          if(machineType!=None):
           nodeType[machineType]=1              
    return machineType

#Finding total machines on each server
def totalMachines(machineArray):
    return len(machineArray)

#Initializing json string for each server
def createJson():
    jsonString = """
    {

    }
    """
    data = json.loads(jsonString)
    return data

def main():
    parseConfig()

main()
