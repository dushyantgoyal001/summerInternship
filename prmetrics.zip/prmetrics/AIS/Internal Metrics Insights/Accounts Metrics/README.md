# Account Metrics

The code consists of 2 files
- JenkinsFile
- Parser python file (Can also work as standalone)

**Note :** 
- There will be one jenkins job on each controller which runs this jenkinsFile. 
- Stages mentioned in jenkinsFile will be running on master node.
- All the accounts info present in Lockable resources are stored in master node in ${JENKINS_HOME}/org.jenkins.plugins.lockableresources.LockableResourcesManager.xml file 

**Workflow:**
1. Once the job starts, this repo will be cloned in master node under JENKINS_HOME/workspace/JobName as part of "Declarative Checkout SCM stage". Then each subsequent stages which are mentioned in jenkinsFile will be executed.
2. During "Get Accounts Info" stage, the parser python script is called with 2 arguments 
   - Input XML file which is org.jenkins.plugins.lockableresources.LockableResourcesManager.xml  
   - Output Json file which is later created and populated by python script with parsed info
3. Python script parses the xml, calls the relevant APIs with the CC accounts which are obtained by parsing xml, then parse the API response body and stores the result in json file.
4. Once the json is created , the handle goes back to jenkinsFile where in "Parse output" stage, this json data is converted in HTML format which is then sent via email to respective engineers.
