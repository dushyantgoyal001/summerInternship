import xml.etree.ElementTree as ET
import json
import argparse
import requests
import os

# Global Variables
accountsList = {}
invalid_creds = []


parser = argparse.ArgumentParser()
parser.add_argument("-p", "--path", required=True, default=None, action='store', help="Specify location of xml file.")
parser.add_argument("-l", "--accountLabel", required=False, default=None, action='store', help="Specify account label which is used in locakable resources.")
parser.add_argument("-o", "--outputFile", required=False, default="accountsInfo.json", action='store', help="Specify the output json file name in which the accounts details will be stored.")
args = parser.parse_args()

outputAccountsInfoJson = args.outputFile
clientIdProd = os.getenv("CLIENT_ID_PROD")
clientSecretProd = os.getenv("CLIENT_SECRET_PROD")
clientIdStage = os.getenv("CLIENT_ID_STAGE")
clientSecretStage = os.getenv("CLIENT_SECRET_STAGE")


def parseXML(xmlfile):
    tree = ET.parse(xmlfile)
    root = tree.getroot()
    for item in root.findall('./resources/org.jenkins.plugins.lockableresources.LockableResource'):
        for child in item:
            if child.tag == "name":
                #print(child.text)
                resourceName = json.loads(child.text)
                continue
            if child.tag == "labels":
                resourceLabel = child.text
                break

        if resourceLabel not in accountsList.keys():
            accountsList[resourceLabel] = []

        if("userEmail" in resourceName):
            localAccount = {"email": resourceName["userEmail"], "password": resourceName["userPassword"]}
            accountsList[resourceLabel].append(localAccount)

        if("remoteEmail" in resourceName):
            remoteAccount = {"email": resourceName["remoteEmail"],"password": resourceName["remotePassword"]}
            accountsList[resourceLabel].append(remoteAccount)


def printAccountsOfSpecificLabel(accountLabel):
    print("Label : ", accountLabel)
    print("Accounts")
    for account in accountsList[accountLabel]:
        print("Email : ", account["email"])
        print("Password : ", account["password"])
        print("Environment : ", account["Env"])
        print("Storage Region : ", account["storage_location"])
        print("Credentials Validitiy  : ", account["Valid"])
        print("UUID  : ", account["UUID"])
        print("Error  : ", account["Error"])
        print("Account Type  : ", account["account_type"])


def printAccountList():
    if args.accountLabel != None:
        if args.accountLabel not in accountsList.keys():
            raise Exception("There are no accounts available with this label in this Jenkins Server. Please provide valid label")
        else:
            printAccountsOfSpecificLabel(args.accountLabel)
    else:
        for accountLabel, val in accountsList.items():
            printAccountsOfSpecificLabel(accountLabel)


def storeAccountInfoInJson():
    if args.accountLabel != None:
        if args.accountLabel not in accountsList.keys():
            raise Exception("There are no accounts available with this label in this Jenkins Server. Please provide valid label")
        else:
            with open(outputAccountsInfoJson, 'w') as f:
                json.dump({args.accountLabel : accountsList[args.accountLabel]}, f)
    else:
        with open(outputAccountsInfoJson, 'w') as f:
                json.dump(accountsList, f)
            


def getStorageRegion(ims_auth_url, email, password, clientID, clientSecret):
    
    account_info = {}
    account_info["invalid"] = "false"
    account_info["storage_location"] = ""
    account_info["paid"] = ""
    account_info["UUID"] = ""
    account_info["Error"] = "None"
    account_info["account_type"] = ""

    header = {
        'Content-Type': 'application/x-www-form-urlencoded', 
    }
    
    data = {
        "grant_type"    : "password",
        "scope"         : "openid,AdobeID,creative_cloud,creative_sdk,read_organizations,sao.cce_private,additional_info.account_type,account_cluster.read",
        "username"      : email,
        "password"      : password,
        "client_id"     : clientID,
        "client_secret" : clientSecret
    }

    imsAuthResponse = requests.post(ims_auth_url, headers=header, data=data)
    responseBody = json.loads(imsAuthResponse.content)
    if imsAuthResponse.status_code != 200:
        if responseBody["error"] == "invalid_credentials":
            account_info["Error"] = "Authentication failed for " + email
            print(account_info["Error"])
            account_info["invalid"] = "true"
            return account_info
        else:
            account_info["Error"] = "API Call failed for " + email + " with error " + responseBody["error"]
            print(account_info["Error"])
            return account_info
    
    print("Email  : " + email)
    try:
        account_info["UUID"] = responseBody["userId"]
        account_info["account_type"] = responseBody["account_type"]
        serviceAccountsList = responseBody["serviceAccounts"]
        for account in serviceAccountsList:
            if account["serviceCode"] == "creative_cloud":
                for x in account["params"]:
                    if x["pn"] == "storage_region":
                        account_info["storage_location"] = x["pv"]
                    if x["pn"] == "storage_quota":
                        if x["pv"] == "100":
                            account_info["paid"] = "YES"
                        else:
                            account_info["paid"] = "NO"

    except:
        account_info["Error"] = "Error in parsing the output for " + email + "Refer Jenkins Job log for checking the output of API call"
        print(account_info["Error"])
        print(responseBody)

    return account_info


def getDetailsOfAllAccountsOfSpecificLabel(accountLabel):
    global clientIdProd, clientSecretProd, clientIdStage, clientSecretStage

    if "prod" in accountLabel.lower():
        ims_auth_url = "https://ims-na1.adobelogin.com/ims/token/v2"
        clientID = clientIdProd
        clientSecret = clientSecretProd
    else:
        ims_auth_url = "https://ims-na1-stg1.adobelogin.com/ims/token/v2"
        clientID = clientIdStage
        clientSecret = clientSecretStage

    for index in range(len(accountsList[accountLabel])):
        account = accountsList[accountLabel][index]
        account_info = getStorageRegion(ims_auth_url, account["email"], account["password"], clientID, clientSecret)
        if account_info["invalid"] == "true":
            accountsList[accountLabel][index]["Valid"] = "NO"
        else:
            accountsList[accountLabel][index]["Valid"] = "YES"

        if "prod" in accountLabel.lower():
            accountsList[accountLabel][index]["Env"] = "Production"
        else:
            accountsList[accountLabel][index]["Env"] = "Stage"
        accountsList[accountLabel][index]["account_type"] = account_info["account_type"]
        accountsList[accountLabel][index]["UUID"] = account_info["UUID"]
        accountsList[accountLabel][index]["paid"] = account_info["paid"]
        accountsList[accountLabel][index]["Error"] = account_info["Error"]
        accountsList[accountLabel][index]["storage_location"] = account_info["storage_location"]


def getDetailsOfAllAccounts():
    if args.accountLabel != None:
        if args.accountLabel not in accountsList.keys():
            raise Exception("There are no accounts available with this label in this Jenkins Server. Please provide valid label")
        else:
            accountLabel = args.accountLabel
            getDetailsOfAllAccountsOfSpecificLabel(accountLabel)
    else:
        for accountLabel, val in accountsList.items():
            getDetailsOfAllAccountsOfSpecificLabel(accountLabel)


def main():
    # Parse XML File 
    parseXML(args.path)
    
    # getDetails of all accounts
    getDetailsOfAllAccounts()
    
    # Print Accounts obtained from parsing xml file
    # printAccountList()

    # Store accounts data in json file 
    storeAccountInfoInJson()


main()