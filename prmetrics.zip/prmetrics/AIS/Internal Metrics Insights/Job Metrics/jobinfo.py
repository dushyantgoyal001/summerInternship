import os
import json
import jenkins
import calendar
import time
from datetime import datetime, timedelta
from datetime import date

#Global variables
individualJobInfo = []
serverInfo = []
lastBuildInfo = []

#Fetching time duration from environment varibales in jenkinsFile
stringTimeDuration = os.getenv("Duration")
# stringTimeDuration = "24"
intTimeDuration = int(stringTimeDuration)
startDate = datetime.now() + timedelta(hours=-intTimeDuration)
stopDate = datetime.now()

currentTimestamp = calendar.timegm(time.gmtime())
stringCurrentTimestamp=str(currentTimestamp)


#Parse configuration file
def parseConfig():
        fullPath = os.path.realpath(__file__)
        cwd = os.path.dirname(fullPath)
        configFile = open(cwd+"/config.json", 'r')
        configContent = configFile.read()
        jsonConfigContent = json.loads(configContent)
        
        for individualServer in jsonConfigContent['servers']:
            url = individualServer["jenkinsUrl"]
            formattedURL= "https://"+url
            serverName = individualServer["name"]
            userid = individualServer["user"]
            apiToken = individualServer["userToken"]

            server = jenkins.Jenkins(
                formattedURL,
                username=userid,
                password=apiToken,
            )

            jsonObject = createJson()
            jobMetricsInfo(server, jsonObject, serverName, formattedURL)

            with open(serverName +"_jobMetrics_"+stringCurrentTimestamp+ ".json", "w") as f:
                json.dump(jsonObject, f, indent=2, default=str)

            serverInfo.clear()
            lastBuildInfo.clear()    

def fillLastJobInfo(server , jsonObject):
    
    totalJobs = server.get_jobs()
    for job in totalJobs:
      if(job['_class'] != "org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject"):
        jobInfo = server.get_job_info(name=job["fullname"], fetch_all_builds=True)
        x = len(jobInfo['builds'])
        if (x!=0) :
            last_build_number = jobInfo['lastBuild']['number']
            buildInfo = server.get_build_info(name=job["fullname"], number=last_build_number)
            if(buildInfo["building"]==True):
                    continue
            data = {
                "jobName" : job["fullname"],
                "lastBuildNumber" : last_build_number,
                "InactiveDays" : InactiveDays(buildInfo),
            }
        else :
            data ={
                "jobName" : job["fullname"],
                "lastBuildNumber" : -1,
                "InactiveDays" : -1,
            }
        lastBuildInfo.append(data)

    jsonObject['lastBuildInfo']=lastBuildInfo

#function to find how many days are in inactive
def InactiveDays(buildInfo):
    currentSeconds=buildInfo['timestamp']/1000
    durationInSeconds = buildInfo["duration"]/1000
    for list in buildInfo['actions']:
        if("waitingTimeMillis" in list):
            waitingTimeMillis = list["waitingTimeMillis"]
            waitingTimeSeconds = waitingTimeMillis/1000
    totalSeconds = currentSeconds+durationInSeconds+waitingTimeSeconds
    lastBuildDate = datetime.utcfromtimestamp(totalSeconds).strftime('%Y %m %d')
    today = date.today()
    todaysDate = today.strftime("%Y %m %d")
    date_format = "%Y %m %d"
    a = datetime.strptime(todaysDate, date_format)
    b = datetime.strptime(lastBuildDate, date_format)
    delta = a - b
    return delta.days


#Jobs which ran during a particular period according to start and stop date
def jobsOverAPeriod(server, jsonObject):

    totalJobs = server.get_jobs()
    for job in totalJobs:
        if(job['_class'] != "org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject"):
            jobInfo = server.get_job_info(name=job["fullname"], fetch_all_builds=True)
            freqOfBuilds=0
            individualJobInfo.clear()

            for build in jobInfo["builds"]:
                buildNumber = build["number"]

                buildInfo = server.get_build_info(name=job["fullname"], number=buildNumber)
                if(buildInfo["building"]==True):
                    continue

                buildDate = datetime.utcfromtimestamp(buildInfo["timestamp"] / 1000)
                formatBuildDate = beautifyTime(buildInfo["timestamp"] / 1000)
                queueTime=calculateWaitingTime(buildInfo)
                finishDate=finishTime(buildInfo,buildDate)
                formatFinishDate = formatFinishTime(buildInfo)

                if  finishDate>= startDate and finishDate <= stopDate:
                    freqOfBuilds+=1
                    buildingDurationInSeconds=(buildInfo['duration']/1000)
                    node, account = findingParameters(buildInfo) 
                    buildMetrics = {
                        "buildNo": buildNumber,
                        "url": buildInfo["url"],
                        "result": buildInfo["result"],
                        "startTime": formatBuildDate,
                        "duration": buildingDurationInSeconds,
                        "queueTime":queueTime,
                        "finishTime": formatFinishDate,
                        "node": node,
                        "account": account
                    }
                    individualJobInfo.append(buildMetrics)
                else:
                    break  

            #Condition for pushing data into json
            if(len(individualJobInfo)!=0):
                updateJson(jsonObject,job["fullname"],individualJobInfo,freqOfBuilds)
        
    #Pushing all information under one key in json file
    jsonObject['jobsInfo']=serverInfo



#Updating Json
def updateJson(jsonObject,projectname,individualJobInfo,frequencyOfBuilds):
    data={
        "jobName":projectname,
        "buildInfo":[],
        "frequency":frequencyOfBuilds
    }
    data['buildInfo']+=individualJobInfo
    serverInfo.append(data)

#Number of jobs in the server
def numberOfJobs(server):
    jobs = server.get_jobs()
    jobCount = len(jobs)
    return jobCount

#Job Metrics-basic information
def jobMetricsInfo(server, jsonObject, serverName, url):
    user = server.get_whoami()
    version = server.get_version()
    jobCount = numberOfJobs(server)
    jsonObject['serverName'] = serverName
    jsonObject['serverUrl'] = url
    jsonObject['jobsCount'] = jobCount
    jobsOverAPeriod(server, jsonObject)
    fillLastJobInfo(server , jsonObject)


#Formatting timestamp
def beautifyTime(totalSeconds):
    dateInUTC = datetime.utcfromtimestamp(totalSeconds)
    trimDate=dateInUTC.replace(microsecond=0)
    dateObject = datetime.strptime(str(trimDate), '%Y-%m-%d %H:%M:%S')
    formattedDateString = dateObject.strftime('%d_%B_%Y_%I:%M:%S_%p')
    return formattedDateString

#Formatting Finish Time
def formatFinishTime(buildInfo):
    startTimeSeconds=buildInfo['timestamp']/1000
    durationSeconds = buildInfo["duration"]/1000
    for list in buildInfo['actions']:
        if("waitingTimeMillis" in list):
            waitingTimeMillis = list["waitingTimeMillis"]
            waitingTimeSeconds = waitingTimeMillis/1000
    totalSeconds = startTimeSeconds+durationSeconds+waitingTimeSeconds
    finishTime = beautifyTime(totalSeconds)
    return finishTime

#Calculating Waiting Time
def calculateWaitingTime(buildInfo):
    for list in buildInfo['actions']:
        if("waitingTimeMillis" in list):
            waitingTimeMillis = list["waitingTimeMillis"]
            waitingTimeSeconds = waitingTimeMillis/1000
    return waitingTimeSeconds

#Calculating Finish Time
def finishTime(buildInfo,buildDate):
    durationInSeconds=buildInfo["duration"]/1000
    for list in buildInfo['actions']:
        if("waitingTimeMillis" in list):
            waitingTimeMillis=list["waitingTimeMillis"]
            waitingTimeSeconds = waitingTimeMillis/1000
    totalSeconds = durationInSeconds+waitingTimeSeconds
    finishTime=buildDate+timedelta(seconds=totalSeconds)
    return finishTime

#Finding Node and Account associated with the Job
def findingParameters(buildInfo):
    node = ""
    account = ""
    for list in buildInfo['actions']:
        if("parameters" in list):
            for parameter in list["parameters"]:
                if(parameter['name']=="SLAVE_LABEL"):
                    node=parameter['value']                      
                if(parameter['name']=="ACCOUNT_POOL"):
                    account=parameter['value']

    return node, account

#Initializing json string for each server
def createJson():
    jsonString = """
    {

    }
    """
    data = json.loads(jsonString)
    return data

def main():
    parseConfig()

main()