import jenkins
import json
import time
import os
from   datetime import  timedelta
from   datetime import datetime 
import calendar
import requests
from requests.auth import HTTPBasicAuth
  
# Global Arrays
projectInfoArray = []
jobInfoArray     = []
buildInfoArray   = []
stageInfoArray   = []

# stringTimeDuration = "24"
stringTimeDuration =  os.getenv("Duration")

intTimeDuration = int(stringTimeDuration)

# getting current timeStamp
currentTimestamp= calendar.timegm(time.gmtime())
stringCurrentTimestamp=str(currentTimestamp)

def PrCountInGivenTimePeriod(startDate , endDate):
    try:
        full_path = os.path.realpath(__file__)
        cwd = os.path.dirname(full_path)
        fileName       = open(cwd + "\config.json")

        configInfo     = json.load(fileName)
        for servers_info in configInfo:
            configApiUrl   = "https://" +  servers_info['api_url'] + "/"
            configUsername = servers_info['username']
            configPass    = servers_info['password']
            server  = getServerInstance(configApiUrl,configUsername, configPass)
            getJobDetails(startDate , endDate , server , servers_info)
            projectInfoArray.clear()
           
        fileName.close()
    except FileNotFoundError:
        print("please check the file path of config file")
        return 

# Making a jenkins server: 
def getServerInstance(apiUrl , userName , password):
    server_instance = jenkins.Jenkins(
        apiUrl,
        username = userName,
        password = password
    )
    return server_instance

def convertDateIntoTimestamp(date) :  
    timestamp = datetime.timestamp(date)
    return timestamp

def getJobDetails(start_date , end_date , server , servers_info):  
    configProject  = servers_info['project_name']
    
    json_object = createJSONString(server)
    fillServerInfo(json_object , server , servers_info)
    
    for job_instance in configProject: 
        project_name = job_instance['name']    
        project_url = job_instance['url']
        repoInstance = server.get_job_info(project_name, depth=1, fetch_all_builds=True)
        repoUrl2     = repoInstance['url']
        prCount      = getJobOverAPeriod(repoInstance , start_date , end_date , servers_info , project_url ) 
        fillProjectInfo(project_name , repoUrl2 , prCount)   
        jobInfoArray.clear()      
    json_object['projectInfo'] = projectInfoArray
    with open ( servers_info['name'] + "_PR_metric_" + stringCurrentTimestamp+ ".json" , "w") as f:
        json.dump(json_object , f , indent = 2 , default=str)


def fillProjectInfo(projectName , projectUrl , prCount):
    data = {
        "projectName"      : projectName,
        "projectUrl"       : projectUrl,
        "numberOfPRruns" : prCount,
        "jobsInfo"          : []        
    }
    data['jobsInfo'] += jobInfoArray
    projectInfoArray.append(data)

#function containing server info
def fillServerInfo(json_object ,server , servers_info):
    configApiUrl   = servers_info['api_url']
    configName    = servers_info['name']

    json_object['serverName']  = configName
    json_object['serverUrl']   = configApiUrl
    json_object['jobsCount']    = number_Of_Jobs(server)
    json_object['projectInfo'] = []

#function to fill job_info array
def fillJobInfo( jobName , prCount ):
    prnum = jobName[3:]
    data = {
        "jobName"   : jobName,
        "totalRuns" : prCount,
        "prNumber"  : int(prnum),
        "buildInfo" : []
    }
    data['buildInfo'] += buildInfoArray 
    jobInfoArray.append(data)

#function to fill build info
def fillBuildInfo(buildNumber , timeStamp , result , buildInformation  , url , configInfo):
    queueTime = waitingDuration(buildInformation)/1000
    Duration = buildInformation['duration']/1000
    formatFinishDate = formatFinishTime(buildInformation)
    fillStageInfo(url , configInfo )
    data = {
        "buildNo": buildNumber,
        "url" : url,
        "result": result,
        "queueTimeSeconds": queueTime ,
        "duration": Duration ,        
        "startTime": beautifyTime(timeStamp),
        "finishTime" : formatFinishDate,
        "stageInfo"  : []
    }
    data['stageInfo'] += stageInfoArray
    stageInfoArray.clear()
    buildInfoArray.append(data)

def fillStageInfo(url , configInfo):
    configUsername = configInfo['username']
    configPass = configInfo['password']
    response = requests.get(url + 'wfapi/',auth = HTTPBasicAuth(configUsername, configPass))
    jsonWeGot = response.json()
    arrayOfStages = jsonWeGot['stages']
    for stageInfo in arrayOfStages:
        data = {
            "stageName" : stageInfo['name'],
            "stageDuration" : stageInfo['durationMillis']/100,
            "stageStatus" : stageInfo['status']
        }
        stageInfoArray.append(data)
        



def formatFinishTime(buildInfo):
    currentSeconds=buildInfo['timestamp']/1000
    durationInSeconds = buildInfo["duration"]/1000
    for list in buildInfo['actions']:
        if("waitingTimeMillis" in list):
            waitingTimeMillis = list["waitingTimeMillis"]
            waitingTimeSeconds = waitingTimeMillis/1000
    totalSeconds = currentSeconds+durationInSeconds+waitingTimeSeconds
    finishTime = beautifyTime(totalSeconds)
    return finishTime



def getJobOverAPeriod(repo_instance , start_date , end_date , servers_info , project_url):

        configUsername = servers_info['username']
        configPass    = servers_info['password']
        configUrl = servers_info['api_url']

        repo_url = "https://" + configUrl +project_url + 'view/change-requests/'
        totalNumberPR = 0    
        
        server2 = getServerInstance(repo_url , configUsername ,configPass)
        for job_name in server2.get_all_jobs():
            info = server2.get_job_info(job_name['fullname'])
            buildss = info['builds']
            pr_count = 0
            for build in buildss:   
                                       
                buildInformation = server2.get_build_info(job_name['name'], build['number'])
                if (buildInformation["building"] == False):
                    time_value = buildInformation['timestamp']
                    if (time_value > start_date and time_value < end_date) :
                        build_date = datetime.utcfromtimestamp(time_value/1000)
                        totalNumberPR += 1  
                        pr_count+= 1 
                        fillBuildInfo(build['number'] , buildInformation['timestamp']/1000 , buildInformation['result'] , buildInformation , buildInformation['url'] , servers_info)
                    else :
                        break
            if(len(buildInfoArray) != 0):
                fillJobInfo(job_name['fullname'] ,pr_count)
            buildInfoArray.clear() 
        return totalNumberPR   


def waitingDuration(build_info ):
    for list in build_info['actions']:
        if 'waitingTimeMillis' in list:
            waitingTimeMillis = list['waitingTimeMillis']+list['buildableTimeMillis']    
    return waitingTimeMillis

def beautifyTime(input):    
    input2 = datetime.utcfromtimestamp(input)
    d = datetime.strptime(str(input2), '%Y-%m-%d %H:%M:%S.%f')
    s = d.strftime('%d_%B_%Y_%I:%M:%S_%p')
    return s

def convertMillis(millis):
    seconds=(millis/1000)%60
    minutes=(millis/(1000*60))%60
    hours=(millis/(1000*60*60))%24
    return int(seconds), int(minutes), int(hours)

def number_Of_Jobs(server):
    job = server.jobs_count()
    return job

def createJSONString(server):
    json_string = """
    {
        
    }
    """
    data = json.loads(json_string)
    return data


def main():
    
    val = datetime.now() -  timedelta(hours= intTimeDuration)
    start_date = convertDateIntoTimestamp(val)
    ts = time.time()
    end_date = ts

    PrCountInGivenTimePeriod(int(start_date*1000) , int(end_date*1000))
    

main()